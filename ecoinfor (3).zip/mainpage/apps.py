from django.apps import AppConfig


class MainpageConfig(AppConfig):
    name = 'mainpage'
